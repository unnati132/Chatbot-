import streamlit as st
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import os
import json

DATA_DIR = "./data"
CSV_PATH = os.path.join(DATA_DIR, "train24K.csv")
EMB_PATH = os.path.join(DATA_DIR, "embeddings.npy")
INDEX_PATH = os.path.join(DATA_DIR, "faiss_index.idx")
META_PATH = os.path.join(DATA_DIR, "meta.json")

@st.cache_resource(show_spinner=True)
def load_index_and_data():
    if not (os.path.exists(EMB_PATH) and os.path.exists(INDEX_PATH)):
        st.error("Embeddings or FAISS index files missing. Run embedding generation script first.")
        return None, None, None
    
    # Load FAISS index
    index = faiss.read_index(INDEX_PATH)
    
    # Load metadata
    with open(META_PATH) as f:
        meta = json.load(f)
    embedder = SentenceTransformer(meta["embedding_model"])
    
    # Load dataframe
    df = pd.read_csv(CSV_PATH)
    df = df[['Question', 'Answer']].dropna().reset_index(drop=True)
    
    return index, embedder, df

def search_answers(query, index, embedder, df, top_k=3):
    q_emb = embedder.encode([query], convert_to_numpy=True).astype('float32')
    faiss.normalize_L2(q_emb)
    D, I = index.search(q_emb, top_k)
    
    results = []
    for idx in I[0]:
        if idx < len(df):
            results.append({
                'question': df.iloc[idx]['Question'],
                'answer': df.iloc[idx]['Answer']
            })
    return results

def main():
    st.title("Chatbot")

    index, embedder, df = load_index_and_data()
    if index is None:
        return

    user_question = st.text_input("Ask your question about periods:")

    if user_question:
        results = search_answers(user_question, index, embedder, df)
        if results:
            st.markdown("### Top relevant answers:")
            for i, res in enumerate(results, 1):
                st.markdown(f"**Q:** {res['question']}")
                st.markdown(f"**A:** {res['answer']}\n")
        else:
            st.write("No relevant answers found. Try rephrasing your question.")

if __name__ == "__main__":
    main()
